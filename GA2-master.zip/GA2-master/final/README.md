# EC final project
> 0416235 劉昱劭

* What: K shortest path problem with bandwidth constraint.
* Why: I took another class about search algorithm. I want to modify the traditional search algorithm combined with EA.
* How: GA (with crossover, mutation)
    * Seeding by IDDFS to get better initial population.

* For details, see [Propasal](https://github.com/AilurusUmbra/GA2/blob/master/final/EC_proposal_0416235.pdf)
* [Progress ...](https://hackmd.io/W_nAemLXSA62kz3pJA2pwA?view)
