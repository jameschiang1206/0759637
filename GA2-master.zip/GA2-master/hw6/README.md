# hw6 
> 0416235 劉昱劭

## 1. 執行方式
python hw6_0416235_prob1.py -i hw6_0416235_prob1.cfg
python hw6_0416235_prob2.py -i hw6_0416235_prob2.cfg

## 2. 檔案架構

* 主程式：hw6_0416235_prob1.py (hw6_0416235_prob2.py) 

* 主程式會 import 以下三個 module
	* Individual.py
	* Population.py
	* Fitness.py

* 兩題各有一個 config file，如上面執行方式分別下指令即可。
	* hw6_0416235_prob1.cfg
	* hw6_0416235_prob2.cfg
