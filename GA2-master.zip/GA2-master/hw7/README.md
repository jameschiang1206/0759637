# To run: python hw7_0416235.py --input hw7_0416235.cfg

* 在 hw7_0416235.cfg 內有一項 numProcesses: 1 可指定要用幾個 process 跑
	* e.g. 若 numProcesses: 4
		會自動跑 1~4 個 process 的情況與圖

	* 跑完後按 enter 即可結束程式，或直接下 ctrl + C 中斷程式

* 關於 fitness function 的 sleep，直接寫死在 Evaluator.py 內。