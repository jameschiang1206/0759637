# Kaggle competition - [NYC Taxi Fare](https://www.kaggle.com/c/new-york-city-taxi-fare-prediction)
*  requirements:
   * numpy=1.15.3
   * pandas=0.20.3
   * matplotlib=3.0.1
   * scikit-learn=0.20.0
